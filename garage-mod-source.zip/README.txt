GARAGE MOD (source project) - Minecraft 1.20.1, Forge 47.x, Java 17

WHAT IT DOES
  /garages                      -> spawns a SMALL, a MEDIUM and a LARGE garage in a row, south of you
  /garage small|medium|large    -> spawns just one of that size
  Each garage has an open doorway (facing you), lanterns, random chests/barrels (vanilla loot tables,
  bigger garage = more containers and better loot) and random junk blocks on the floor.
  No other mods needed.

BUILD THE .JAR WITH GITHUB (no programming needed)
  1. Create a free repository on github.com (New repository).
  2. Upload ALL files of this folder into it (drag and drop in the browser).
     IMPORTANT: the hidden folder ".github" must be uploaded too. If it is missing, click
     "Add file > Create new file", type the name  .github/workflows/build.yml  and paste the
     contents of build.yml from this project.
  3. Open the "Actions" tab. The "Build mod" job starts by itself (or press "Run workflow").
  4. When it is green, open the run and download the artifact "garageauction-jar".
     Unzip it: garageauction-1.20.1-1.0.0.jar is your mod.
  5. Put the jar into  <instance>/minecraft/mods  of a Forge 1.20.1 instance and start the game.
  If the build is red, copy the error text from the log and send it to me.

BUILD LOCALLY (optional): install JDK 17 + Gradle 8.1.1, then run:  gradle build
  The jar appears in build/libs.
