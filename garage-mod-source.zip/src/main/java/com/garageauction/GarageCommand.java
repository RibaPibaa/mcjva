package com.garageauction;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;

public final class GarageCommand {
    private GarageCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        // /garages  -> one small, one medium, one large in a row
        dispatcher.register(Commands.literal("garages").executes(ctx -> spawnAll(ctx.getSource())));

        // /garage small | medium | large
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("garage");
        for (GarageSize size : GarageSize.values()) {
            root.then(Commands.literal(size.id).executes(ctx -> spawnOne(ctx.getSource(), size)));
        }
        dispatcher.register(root);
    }

    private static int spawnAll(CommandSourceStack src) {
        ServerLevel level = src.getLevel();
        BlockPos p = BlockPos.containing(src.getPosition());
        GarageSize[] sizes = GarageSize.values();
        int gap = 3;
        int total = gap * (sizes.length - 1);
        for (GarageSize s : sizes) {
            total += s.width;
        }
        int x = p.getX() - total / 2;
        int z = p.getZ() + 4;
        for (GarageSize s : sizes) {
            GarageBuilder.build(level, new BlockPos(x, p.getY(), z), s);
            x += s.width + gap;
        }
        src.sendSuccess(() -> Component.literal("Spawned a small, a medium and a large garage south of you."), true);
        return 1;
    }

    private static int spawnOne(CommandSourceStack src, GarageSize size) {
        ServerLevel level = src.getLevel();
        BlockPos p = BlockPos.containing(src.getPosition());
        BlockPos corner = new BlockPos(p.getX() - size.width / 2, p.getY(), p.getZ() + 4);
        GarageBuilder.build(level, corner, size);
        src.sendSuccess(() -> Component.literal("Spawned a " + size.id + " garage south of you."), true);
        return 1;
    }
}
