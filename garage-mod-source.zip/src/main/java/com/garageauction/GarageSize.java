package com.garageauction;

public enum GarageSize {
    //          id        width depth containers junk
    SMALL("small", 9, 7, 2, 6),
    MEDIUM("medium", 13, 9, 4, 12),
    LARGE("large", 17, 11, 7, 22);

    public final String id;
    public final int width;
    public final int depth;
    public final int containers;
    public final int junk;

    GarageSize(String id, int width, int depth, int containers, int junk) {
        this.id = id;
        this.width = width;
        this.depth = depth;
        this.containers = containers;
        this.junk = junk;
    }
}
