package com.garageauction;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Builds one garage. "corner" is the north-west corner at floor-walking level
 * (the player's feet height). The doorway is on the north wall (facing the player
 * who stands north of it).
 */
public final class GarageBuilder {
    private GarageBuilder() {}

    private static final int H = 4; // interior height

    private static final Block[] JUNK = {
        Blocks.HAY_BLOCK, Blocks.OAK_LOG, Blocks.COBWEB, Blocks.CRAFTING_TABLE, Blocks.COMPOSTER,
        Blocks.CAULDRON, Blocks.BOOKSHELF, Blocks.FURNACE, Blocks.LOOM, Blocks.JUKEBOX,
        Blocks.WHITE_WOOL, Blocks.COAL_BLOCK, Blocks.BRICKS, Blocks.RED_CARPET, Blocks.SPRUCE_PLANKS,
        Blocks.COBBLESTONE, Blocks.MOSSY_COBBLESTONE, Blocks.BARREL, Blocks.ANVIL, Blocks.NOTE_BLOCK
    };

    private static final String[] COMMON_LOOT = {
        "minecraft:chests/village/village_plains_house",
        "minecraft:chests/village/village_toolsmith",
        "minecraft:chests/village/village_weaponsmith",
        "minecraft:chests/abandoned_mineshaft",
        "minecraft:chests/igloo_chest",
        "minecraft:chests/shipwreck_supply"
    };

    private static final String[] RARE_LOOT = {
        "minecraft:chests/simple_dungeon",
        "minecraft:chests/desert_pyramid",
        "minecraft:chests/jungle_temple",
        "minecraft:chests/stronghold_corridor",
        "minecraft:chests/pillager_outpost",
        "minecraft:chests/ruined_portal",
        "minecraft:chests/woodland_mansion"
    };

    public static void build(ServerLevel level, BlockPos corner, GarageSize size) {
        RandomSource rand = level.getRandom();
        int w = size.width;
        int d = size.depth;
        int x0 = corner.getX();
        int y0 = corner.getY();
        int z0 = corner.getZ();
        int x1 = x0 + w - 1;
        int z1 = z0 + d - 1;
        int xc = x0 + w / 2;

        BlockState air = Blocks.AIR.defaultBlockState();
        BlockState wall = Blocks.GRAY_CONCRETE.defaultBlockState();
        BlockState floor = Blocks.POLISHED_ANDESITE.defaultBlockState();

        // clear the space and build a foundation
        fill(level, x0 - 1, y0, z0 - 1, x1 + 1, y0 + H + 3, z1 + 1, air);
        fill(level, x0 - 1, y0 - 4, z0 - 1, x1 + 1, y0 - 2, z1 + 1, Blocks.STONE_BRICKS.defaultBlockState());

        // shell: floor, walls, roof
        for (int x = x0; x <= x1; x++) {
            for (int y = y0 - 1; y <= y0 + H + 1; y++) {
                for (int z = z0; z <= z1; z++) {
                    boolean isFloor = y == y0 - 1;
                    boolean isRoof = y == y0 + H + 1;
                    boolean isWall = x == x0 || x == x1 || z == z0 || z == z1;
                    if (isFloor) {
                        set(level, x, y, z, floor);
                    } else if (isRoof || isWall) {
                        set(level, x, y, z, wall);
                    } else {
                        set(level, x, y, z, air);
                    }
                }
            }
        }

        // doorway (3 wide, 3 high) on the north wall
        fill(level, xc - 1, y0, z0, xc + 1, y0 + 2, z0, air);

        // lanterns hanging from the roof
        BlockState lantern = Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true);
        for (int lx = x0 + 2; lx <= x1 - 2; lx += 4) {
            for (int lz = z0 + 3; lz <= z1 - 2; lz += 4) {
                set(level, lx, y0 + H, lz, lantern);
            }
        }

        // interior cells, keeping the lane in front of the door free
        List<BlockPos> edge = new ArrayList<>();
        List<BlockPos> rest = new ArrayList<>();
        for (int x = x0 + 1; x <= x1 - 1; x++) {
            for (int z = z0 + 1; z <= z1 - 1; z++) {
                boolean lane = Math.abs(x - xc) <= 1 && z <= z0 + 2;
                if (lane) {
                    continue;
                }
                if (x == x0 + 1 || x == x1 - 1 || z == z1 - 1) {
                    edge.add(new BlockPos(x, y0, z));
                } else {
                    rest.add(new BlockPos(x, y0, z));
                }
            }
        }
        shuffle(edge, rand);
        shuffle(rest, rand);

        // random chests and barrels with random loot tables
        int containers = Math.min(size.containers, edge.size());
        for (int i = 0; i < containers; i++) {
            BlockPos pos = edge.get(i);
            boolean barrel = rand.nextFloat() < 0.35F;
            BlockState state = barrel
                ? Blocks.BARREL.defaultBlockState().setValue(BarrelBlock.FACING, Direction.UP)
                : Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, Direction.NORTH);
            level.setBlock(pos, state, Block.UPDATE_CLIENTS);
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof RandomizableContainerBlockEntity container) {
                container.setLootTable(new ResourceLocation(pickLoot(size, rand)), rand.nextLong());
            }
        }

        // random junk blocks (some stacked)
        for (int i = 0; i < size.junk && i < rest.size(); i++) {
            BlockPos pos = rest.get(i);
            set(level, pos.getX(), pos.getY(), pos.getZ(), randomJunk(rand));
            if (rand.nextFloat() < 0.25F) {
                set(level, pos.getX(), pos.getY() + 1, pos.getZ(), randomJunk(rand));
            }
        }
    }

    private static String pickLoot(GarageSize size, RandomSource rand) {
        float rareChance = size == GarageSize.LARGE ? 0.45F : size == GarageSize.MEDIUM ? 0.25F : 0.08F;
        String[] pool = rand.nextFloat() < rareChance ? RARE_LOOT : COMMON_LOOT;
        return pool[rand.nextInt(pool.length)];
    }

    private static BlockState randomJunk(RandomSource rand) {
        return JUNK[rand.nextInt(JUNK.length)].defaultBlockState();
    }

    private static void set(ServerLevel level, int x, int y, int z, BlockState state) {
        level.setBlock(new BlockPos(x, y, z), state, Block.UPDATE_CLIENTS);
    }

    private static void fill(ServerLevel level, int x1, int y1, int z1, int x2, int y2, int z2, BlockState state) {
        for (int x = x1; x <= x2; x++) {
            for (int y = y1; y <= y2; y++) {
                for (int z = z1; z <= z2; z++) {
                    set(level, x, y, z, state);
                }
            }
        }
    }

    private static <T> void shuffle(List<T> list, RandomSource rand) {
        for (int i = list.size() - 1; i > 0; i--) {
            int j = rand.nextInt(i + 1);
            T tmp = list.get(i);
            list.set(i, list.get(j));
            list.set(j, tmp);
        }
    }
}
